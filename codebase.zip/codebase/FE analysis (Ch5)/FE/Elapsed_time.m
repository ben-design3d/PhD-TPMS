%Convergance loop
clear
close all
clc

structure = 2;      %Gyroid:1, Diamond:2, Primitive:3

if structure == 1
    density_wt = [0.05,16.1839;0.1,32.5025;0.15,49.0217;0.2,65.8994;0.3,101.2118;0.4,139.8020;0.6,236.9089];%Gyroid
elseif structure == 2
    density_wt = [0.05,13.0258;0.1,26.1923;0.15,39.5011;0.2,53.0779;0.3,81.6101;0.4,112.8589;0.6,192.5489]; %Diamond
elseif structure == 3
    density_wt = [0.05,21.2883;0.1,42.7411;0.15,64.5209;0.2,86.8220;0.3,133.8833;0.4,186.4854;0.5,249.8488]; %Primitive
else
    fprintf('Structure incorrectly defined');
    return
end

%Input filename
filename = 'input';


%input generator
max_divisions = 5;        %How many times the base triangles are subdivided
tests = 5;                %Number of tests performed to average time.

cell_size = 1000;        %Unit cell dimensions (mm)
bulk_stiffness = 180; %GPa
bulk_poisson = 0.3;
wall_thickness = density_wt(4,2);

plot_mesh = false;
plot_norms = false;
plot_nodes = false;
fix_pos = true;
show_output = false;

analysis_test = true;

avg_mesh_time = zeros(max_divisions,1);
avg_analysis_time = zeros(max_divisions,1);
avg_wallclock_time = zeros(max_divisions,1);

for subdivisions = 1:max_divisions
    mesh_time = 0;
    analysis_time = 0;
    wallclock = 0;
    for i = 1:tests
        %timed meshing
        tic
        [verts,elems] = mesh_generation(subdivisions,cell_size,structure,plot_mesh,plot_norms);
        mesh_time = mesh_time + toc;
        
        node_gen(verts,elems,cell_size,structure,plot_nodes,fix_pos);
        input_compiler(filename,structure,cell_size,wall_thickness,bulk_stiffness,bulk_poisson,fix_pos);
        
        %timed analysis
        if analysis_test == true
        [output,time] = abaqus_run_timed(filename,cell_size,show_output);
        analysis_time = analysis_time + time;
        
        %read input file and get wallclock time
        fidd = fopen('input.dat');
        pause(0.5)
        while ( ~feof(fidd) ) %WHILE NOT END OF FILE
            
            tline = fgetl(fidd);
            
            if (regexpi(tline, 'WALLCLOCK')>0)  %if we reach a node output start reading file.
                %tline = fgetl(fidd);
                wallclock = wallclock + sscanf(reverse(tline), '%f');
                
            end
        end
        fclose(fidd);
        end
    end
    no_elems(subdivisions) = length(elems);
    avg_mesh_time(subdivisions) = mesh_time/tests;
    
    if analysis_test == true
        avg_analysis_time(subdivisions) = analysis_time/tests;
        avg_wallclock_time(subdivisions) = wallclock/tests;
    end
    
    
 
end


%%
close all

% plot(gen_time(:,1),gen_time(:,2),'-*','DisplayName','5%');
% hold on
% plot(gen_time(:,3),gen_time(:,4),'-*','DisplayName','10%');
% plot(gen_time(:,5),gen_time(:,6),'-*','DisplayName','15%');
% plot(gen_time(:,7),gen_time(:,8),'-*','DisplayName','20%');
% plot(gen_time(:,9),gen_time(:,10),'-*','DisplayName','30%');
% plot(gen_time(:,11),gen_time(:,12),'-*','DisplayName','40%');
% plot(gen_time(:,13),gen_time(:,14),'-*','DisplayName','60%');
% ylabel('Mesh generation time (s)');
% xlabel('elements');
% title('Diamond mesh generation time');
% legend('Location','southeast');

figure(1)
plot(no_elems,avg_mesh_time,'*-');

ylabel('time (s)');
xlabel('elements');
%title('Meshing time');
fzz = gcf;
exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\meshingtime.pdf','ContentType','vector');

if analysis_test == true
figure(2)
    plot(no_elems,avg_analysis_time,'*-');
    ylim([0 25]);
    ylabel('time (s)');
    xlabel('elements');
    %title('Analysis time');
    fzz = gcf;
    exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\analysistime.pdf','ContentType','vector');
figure(3)
    plot(no_elems,avg_wallclock_time,'*-');
    %ylim([0 25]);
    ylabel('time (s)');
    xlabel('elements');
    %title('WallClock time');
    fzz = gcf;
    exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\wallclocktime.pdf','ContentType','vector');
end


