%Convergance loop
clear
close all
clc

%structure = 2;      %Gyroid:1, Diamond:2, Primitive:3
for structure = 1:3

if structure == 1
    density_wt = [0.05,16.1839;0.1,32.5025;0.15,49.0217;0.2,65.8994;0.3,101.2118;0.4,139.8020;0.6,236.9089];%Gyroid
elseif structure == 2
    density_wt = [0.05,13.0258;0.1,26.1923;0.15,39.5011;0.2,53.0779;0.3,81.6101;0.4,112.8589;0.6,192.5489]; %Diamond
elseif structure == 3
    density_wt = [0.05,21.2883;0.1,42.7411;0.15,64.5209;0.2,86.8220;0.3,133.8833;0.4,186.4854;0.5,249.8488]; %Primitive
else
    fprintf('Structure incorrectly defined');
    return
end

%Input filename
filename = 'input';


%input generator
max_divisions = 4;        %How many times the base triangles are subdivided
    
cell_size = 1000;        %Unit cell dimensions (mm)
bulk_stiffness = 180; %GPa
bulk_poisson = 0.3;

plot_mesh = false;
plot_norms = false;
plot_nodes = false;
fix_pos = true;
show_output = false;

convergance = zeros(max_divisions,length(density_wt)*2);
count = 1;
for i = 1:length(density_wt)
    
    for subdivisions = 1:max_divisions
        %generate model
        tic
        [verts,elems] = mesh_generation(subdivisions,cell_size,structure,plot_mesh,plot_norms);
        time = toc;
        gen_time(subdivisions,count) = length(elems);
        gen_time(subdivisions,count+1) = time;
        node_gen(verts,elems,cell_size,structure,plot_nodes,fix_pos);
        input_compiler(filename,structure,cell_size,density_wt(i,2),bulk_stiffness,bulk_poisson,fix_pos);
        %run model
        output = abaqus_run(filename,cell_size,show_output);
        
        convergance(subdivisions,count) = length(elems);
        convergance(subdivisions,count+1) = output(1)/(bulk_stiffness*10^9);
    end
    count = count + 2;
end

%%
close all
% figure(1)
plot(convergance(:,1),convergance(:,2),'-*','DisplayName','5%');
hold on
plot(convergance(:,3),convergance(:,4),'-*','DisplayName','10%');
plot(convergance(:,5),convergance(:,6),'-*','DisplayName','15%');
plot(convergance(:,7),convergance(:,8),'-*','DisplayName','20%');
plot(convergance(:,9),convergance(:,10),'-*','DisplayName','30%');
plot(convergance(:,11),convergance(:,12),'-*','DisplayName','40%');

if structure == 3
    plot(convergance(:,13),convergance(:,14),'-*','DisplayName','50%');
    xlim([0,12300]);
else
    plot(convergance(:,13),convergance(:,14),'-*','DisplayName','60%');
end

ylabel('E_l/Es');
xlabel('elements');
legend('Location','southeast');

fzz = gcf;
if structure ==1
    exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\gyroid_converge.pdf','ContentType','vector');
elseif structure ==2
    exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\diamond_converge.pdf','ContentType','vector');
else
    exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\primitive_converge.pdf','ContentType','vector');
end

%figure(2)
% plot(gen_time(:,1),gen_time(:,2),'-*','DisplayName','5%');
% hold on
% plot(gen_time(:,3),gen_time(:,4),'-*','DisplayName','10%');
% plot(gen_time(:,5),gen_time(:,6),'-*','DisplayName','15%');
% plot(gen_time(:,7),gen_time(:,8),'-*','DisplayName','20%');
% plot(gen_time(:,9),gen_time(:,10),'-*','DisplayName','30%');
% plot(gen_time(:,11),gen_time(:,12),'-*','DisplayName','40%');
% plot(gen_time(:,13),gen_time(:,14),'-*','DisplayName','60%');
% ylabel('Mesh generation time (s)');
% xlabel('elements');
% title('Diamond mesh generation time');
% legend('Location','southeast');

end
disp('done!');