%Convergance loop
clear
close all
clc

%Input filename
filename = 'input';


%input generator
subdivisions = 4;        %How many times the base triangles are subdivided
    
cell_size = 1000;        %Unit cell dimensions (mm)
%Maraging stell powder Oraib 2018
poisson_ratio = 0.3;
youngs_modulus = 180; %GPa
shear_modulus = youngs_modulus/(2*(1+poisson_ratio));
bulk_modulus = youngs_modulus/(2*(1-2*poisson_ratio));
%yield = 1000;       %MPa
%ultimate = 1100;    %MPa

plot_mesh = false;
plot_norms = false;
plot_nodes = false;
fix_pos = true;
show_output = false;

norm_ex = zeros(3,7);
norm_gxy = zeros(3,7);
zener = zeros(3,7);
uni_iso_index = zeros(3,7);
poisson = zeros(3,7);

for structure = 1:3
    close all
     %generate model
    [verts,elems] = mesh_generation(subdivisions,cell_size,structure,plot_mesh,plot_norms);
    node_gen(verts,elems,cell_size,structure,plot_nodes,fix_pos);
    
    if structure == 1
        density_wt = [0.05,16.1839;0.1,32.5025;0.15,49.0217;0.2,65.8994;0.3,101.2118;0.4,139.8020;0.6,236.9089];%Gyroid
        %RD = [0.05,0.1,0.15,0.2,0.3,0.4,0.6];
        %density_wt = vol_cal(verts,elems,cell_size,RD);
        name = 'Gyroid';
    elseif structure == 2
        density_wt = [0.05,13.0258;0.1,26.1923;0.15,39.5011;0.2,53.0779;0.3,81.6101;0.4,112.8589;0.6,192.5489]; %Diamond
        %RD = [0.05,0.1,0.15,0.2,0.3,0.4,0.6];
        %density_wt = vol_cal(verts,elems,cell_size,RD);
        name = 'Diamond';
    elseif structure == 3
        density_wt = [0.05,21.2883;0.1,42.7411;0.15,64.5209;0.2,86.8220;0.3,133.8833;0.4,186.4854;0.5,249.8488]; %Primitive
        %RD = [0.05,0.1,0.15,0.2,0.3,0.4,0.5];
        %density_wt = vol_cal(verts,elems,cell_size,RD);
        name = 'Primitive';
    end
    
    for i = 1:length(density_wt)
        
        input_compiler(filename,structure,cell_size,density_wt(i,2),youngs_modulus,poisson_ratio,fix_pos);
        %run model
        output = abaqus_run(filename,cell_size,show_output);
        %output = [Ex;Ey;Ez;Gyz;Gzx;Gxy;Vyx;Vzx;Vzy;Vxy;Vxz;Vyz;Ar;Au];
        norm_ex(structure,i) = output(1)/(youngs_modulus*10^9);
        norm_gxy(structure,i) = output(6)/(shear_modulus*10^9);
        zener(structure,i) = output(13);
        uni_iso_index(structure,i) = output(14);
        poisson(structure,i) = output(10);
    end
    
    %power law fit logfit2 is modified to not plot
    %[slope, intercept] = logfit2(x,y,'loglog'); 
    %yApprox = (10^intercept)*x.^(slope); 
    
    [slope_ex, intercept_ex] = logfit2(density_wt(:,1),norm_ex(structure,:).','loglog');
    k(structure,1) = slope_ex;
    m(structure,1) = 10^intercept_ex;
    
    [slope_gxy, intercept_gxy] = logfit2(density_wt(:,1),norm_gxy(structure,:).','loglog');
    k(structure,2) = slope_gxy;
    m(structure,2) = 10^intercept_gxy;

end

%%
%plot Ex
%gyroid
comp = true;

clc
close all
figure(1);
%gyroid
density_gyd = [0.05;0.1;0.15;0.2;0.3;0.4;0.6]; %Gyroid
YBL = (m(1,1))*density_gyd.^(k(1,1));
loglog(density_gyd*100,YBL,'Color',[0, 0.4470, 0.7410]);
hold on
%diamond
density_dia = [0.05;0.1;0.15;0.2;0.3;0.4;0.6]; %Diamond
YBL = (m(2,1))*density_dia.^(k(2,1));
plot(density_dia*100,YBL,'Color',[0.8500, 0.3250, 0.0980]);
%primitive
density_prim = [0.05;0.1;0.15;0.2;0.3;0.4;0.5]; %Primitive
YBL = (m(3,1))*density_prim.^(k(3,1));
plot(density_prim*100,YBL,'Color',[0.9290, 0.6940, 0.1250]);

if comp == true
%Teerapong Poltue
%Gyroid
p_low = 0.15;
p_high = 0.4;
C = 0.61;
n = 1.27;
Enorm_low = C*p_low^n;
Enorm_high = C*p_high^n;
plot([p_low,p_high]*100,[Enorm_low,Enorm_high],'-.','Color',[0, 0.4470, 0.7410]);
%Diamond
p_low = 0.15;
p_high = 0.5;
C = 0.66;
n = 1.26;
Enorm_low = C*p_low^n;
Enorm_high = C*p_high^n;
plot([p_low,p_high]*100,[Enorm_low,Enorm_high],'-.','Color',[0.8500, 0.3250, 0.0980]);
%Primitive
p_low = 0.15;
p_high = 0.55;
C = 0.88;
n = 1.89;
Enorm_low = C*p_low^n;
Enorm_high = C*p_high^n;
plot([p_low,p_high]*100,[Enorm_low,Enorm_high],'-.','Color',[0.9290, 0.6940, 0.1250]);

%Teerapong Poltue references
%Gyroid Abueidda 2019
p_low = 0.15;
p_high = 0.4;
C = 0.62;
n = 1.27;
Enorm_low = C*p_low^n;
Enorm_high = C*p_high^n;
plot([p_low,p_high]*100,[Enorm_low,Enorm_high],':','Color',[0, 0.4470, 0.7410]);
%Diamond Oraib '18
p_low = 0.15;
p_high = 0.5;
C = 0.55;
n = 1.25;
Enorm_low = C*p_low^n;
Enorm_high = C*p_high^n;
plot([p_low,p_high]*100,[Enorm_low,Enorm_high],':','Color',[0.8500, 0.3250, 0.0980]);
%Primitive Dong-Wook
p_low = 0.15;
p_high = 0.55;
C = 0.61;
n = 1.57;
Enorm_low = C*p_low^n;
Enorm_high = C*p_high^n;
plot([p_low,p_high]*100,[Enorm_low,Enorm_high],':','Color',[0.9290, 0.6940, 0.1250]);

%Abueidda 2016
%Gyroid
p_low = 0.02;
p_high = 0.3;
C = 0.555;
n = 1.406;
Enorm_low = C*p_low^n;
Enorm_high = C*p_high^n;
plot([p_low,p_high]*100,[Enorm_low,Enorm_high],'--','Color',[0, 0.4470, 0.7410]);
%Primitive
p_low = 0.02;
p_high = 0.3;
C = 0.562;
n = 1.519;
Enorm_low = C*p_low^n;
Enorm_high = C*p_high^n;
plot([p_low,p_high]*100,[Enorm_low,Enorm_high],'--','Color',[0.9290, 0.6940, 0.1250]);

% %Regression analysis T Maconachie 2019
% %Gyroid Correlation: 1.85%
% p_low = 5;
% p_high = 50;
% C = 0.01;
% n = 0.22;
% Enorm_low = C*p_low^n;
% Enorm_high = C*p_high^n;
% plot([p_low,p_high],[Enorm_low,Enorm_high],':','Color',[0.5, 0.5, 0.5]);
% %Diamond Correlation: 96.61%
% p_low = 5;
% p_high = 50;
% C = 0.05;
% n = 0.76;
% Enorm_low = C*p_low^n;
% Enorm_high = C*p_high^n;
% plot([p_low,p_high],[Enorm_low,Enorm_high],'--','Color',[0.5, 0.5, 0.5]);
end

%real datapoints
 a = loglog(density_gyd(:,1)*100,norm_ex(1,:),'*','Color',[0, 0.4470, 0.7410]);
loglog(density_dia(:,1)*100,norm_ex(2,:),'*','Color',[0.8500, 0.3250, 0.0980]);
loglog(density_prim(:,1)*100,norm_ex(3,:),'*','Color',[0.9290, 0.6940, 0.1250]);

ax = gca;
%ax.XMinorTick = 'on';
ax.XAxis.TickValues = [5,10,15,20,30,40,50,60];
%ax.XAxis.Exponent = 1;

ylabel('E_l/E_s');
xlabel('$\bar{\rho}\; (\%)$','interpreter','latex');
%title('Normalised Axial Stiffness');

if comp == true
    xlim([1.4*10^(1) 6.5*10^1]);
    ylim([2*10^(-2) 4*10^-1]);
    legend('Gyroid','Diamond','Primitive','T.Poltue ''19 Gyrd','T.Poltue ''19 Dia','T.Poltue ''19 Prim','D.W.Abueidda ''19 Gyrd','O.Al-Ketan ''18 Dia','Dong-Wook Prim','D.W.Abueidda ''16 Gyrd','D.W.Abueidda ''16 Prim','Location','southeast');
    fzz = gcf;
    exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\normalisedaxialstiffness_compare.pdf','ContentType','vector');
else
    xlim([4*10^(0) 7*10^1]);
    ylim([5*10^(-3) 4*10^-1]);
    legend('Gyroid','Diamond','Primitive','Location','southeast');
    fzz = gcf;
    exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\normalisedaxialstiffness.pdf','ContentType','vector');
end

%Plot Gxy
figure(2)
%Gyroid
density_gyd = [0.05;0.1;0.15;0.2;0.3;0.4;0.6]; %Gyroid
YBL = (m(1,2))*density_gyd.^(k(1,2));
loglog(density_gyd*100,YBL,'Color',[0, 0.4470, 0.7410]);
hold on
%diamond
density_dia = [0.05;0.1;0.15;0.2;0.3;0.4;0.6]; %Diamond
YBL = (m(2,2))*density_dia.^(k(2,2));
plot(density_dia*100,YBL,'Color',[0.8500, 0.3250, 0.0980]);
%primitive
density_prim = [0.05;0.1;0.15;0.2;0.3;0.4;0.5]; %Primitive
YBL = (m(3,2))*density_prim.^(k(3,2));
plot(density_prim*100,YBL,'Color',[0.9290, 0.6940, 0.1250]);

if comp == true
%Abueidda 2016
%Gyroid
p_low = 0.02;
p_high = 0.3;
C = 0.305;
n = 1.531;
Enorm_low = 2*(1+0.3)*C*p_low^n;
Enorm_high = 2*(1+0.3)*C*p_high^n;
plot([p_low,p_high]*100,[Enorm_low,Enorm_high],'--','Color',[0, 0.4470, 0.7410]);
%Primitive
p_low = 0.02;
p_high = 0.3;
C = 0.160;
n = 0.974;
Enorm_low = 2*(1+0.3)*C*p_low^n; %2*(1+0.3)*converting from E
Enorm_high = 2*(1+0.3)*C*p_high^n;
plot([p_low,p_high]*100,[Enorm_low,Enorm_high],'--','Color',[0.9290, 0.6940, 0.1250]);

%D-W.LEE
%Primitive
p_low = 0.02;
p_high = 0.2;
C = 0.416;
n = 0.97;
Enorm_low = C*p_low^n;
Enorm_high = C*p_high^n;
plot([p_low,p_high]*100,[Enorm_low,Enorm_high],':','Color',[0.9290, 0.6940, 0.1250]);

% %Murton
% %Gyroid
% p_low = 0.1;
% p_high = 0.3;
% %report
% %C = 0.77;
% %n = 3.19;
% %excel
% C = 42.115;
% n = 3.4459;
% Enorm_low = C*p_low^n;
% Enorm_high = C*p_high^n;
% plot([p_low,p_high]*100,[Enorm_low,Enorm_high],':','Color',[0, 0.4470, 0.7410]);

% %Diamond
% p_low = 0.1;
% p_high = 0.3;
% %report
% %C = 0.65;
% %n = 3.19;
% C = 1.8476;
% n = 2.1187;
% Enorm_low = C*p_low^n;
% Enorm_high = C*p_high^n;
% plot([p_low,p_high]*100,[Enorm_low,Enorm_high],':','Color',[0.8500, 0.3250, 0.0980]);
end

%real datapoints
loglog(density_gyd(:,1)*100,norm_gxy(1,:),'*','Color',[0, 0.4470, 0.7410]);
hold on
loglog(density_dia(:,1)*100,norm_gxy(2,:),'*','Color',[0.8500, 0.3250, 0.0980]);
loglog(density_prim(:,1)*100,norm_gxy(3,:),'*','Color',[0.9290, 0.6940, 0.1250]);

xlim([4*10^(0) 7*10^1]);
ylim([5*10^(-3) 4*10^-1]);

ax = gca;
%ax.XMinorTick = 'on';
ax.XAxis.TickValues = [5,10,15,20,30,40,50,60];
%ax.XAxis.Exponent = 1;

ylabel('G_l/G_s');
xlabel('$\bar{\rho}\; (\%)$','interpreter','latex');
%title('Normalised Shear Stiffness');
if comp == true
    legend('Gyroid','Diamond','Primitive','D.W.Abueidda ''16 Gyrd','D.W.Abueidda ''16 Prim','D-W. Lee ''17 Prm','Location','southeast');
    fzz = gcf;
    exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\normalisedshearstiffness_compare.pdf','ContentType','vector');
else
    legend('Gyroid','Diamond','Primitive','Location','southeast');
    fzz = gcf;
    exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\normalisedshearstiffness.pdf','ContentType','vector');
end

%Zener ratio
figure(3)
hold on
plot(density_gyd(:,1)*100,zener(1,:),'-*','Color',[0, 0.4470, 0.7410]);
plot(density_dia(:,1)*100,zener(2,:),'-*','Color',[0.8500, 0.3250, 0.0980]);
plot(density_prim(:,1)*100,zener(3,:),'-*','Color',[0.9290, 0.6940, 0.1250]);
if comp == true
plot([10,30,50],[1.1046,1.1023,1.1002],'-*'); %Dawei Gyroid

den = [2,4,6,8,10,12,14,16,18,20,22,24]/100;
for ii = 1:length(den)
zen(ii) = 4.087*(exp((-3.695*den(ii))));
end
plot(den.*100,zen,'-*');
end
plot([0,65],[1,1],':','Color',[0, 0, 0]);
xlim([0 65]);
ylabel('Zener Ratio');
xlabel('$\bar{\rho}\; (\%)$','interpreter','latex');
%title('Zener Ratio');
if comp == true
    legend('Gyroid','Diamond','Primitive','L.Dawei ''19 Gyrd','D-W. Lee ''17 Prm','Isotropic line','Location','northeast');
    fzz = gcf;
    exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\zenerratio_compare.pdf','ContentType','vector');
else
    legend('Gyroid','Diamond','Primitive','Isotropic line','Location','northeast');
    fzz = gcf;
    exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\zenerratio.pdf','ContentType','vector');
end

%Universal Elastic Anisotropy Index
figure(4)
plot(density_gyd(:,1)*100,uni_iso_index(1,:),'-*','Color',[0, 0.4470, 0.7410]);
hold on
plot(density_dia(:,1)*100,uni_iso_index(2,:),'-*','Color',[0.8500, 0.3250, 0.0980]);
plot(density_prim(:,1)*100,uni_iso_index(3,:),'-*','Color',[0.9290, 0.6940, 0.1250]);
xlim([0 65]);
ylabel('Au');
xlabel('$\bar{\rho}\; (\%)$','interpreter','latex');
%title('Universal Elastic Anisotropy Index');
legend('Gyroid','Diamond','Primitive','Location','northeast');
fzz = gcf;
exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\UEAI.pdf','ContentType','vector');

%Log Universal Elastic Anisotropy Index
figure(5)
loglog(density_gyd(:,1)*100,uni_iso_index(1,:),'-*','Color',[0, 0.4470, 0.7410]);
hold on
loglog(density_dia(:,1)*100,uni_iso_index(2,:),'-*','Color',[0.8500, 0.3250, 0.0980]);
loglog(density_prim(:,1)*100,uni_iso_index(3,:),'-*','Color',[0.9290, 0.6940, 0.1250]);
xlim([4*10^(0) 7*10^(1)]);
ylim([7*10^(-4) 3*10^(0)]);

ax = gca;
%ax.XMinorTick = 'on';
ax.XAxis.TickValues = [5,10,15,20,30,40,50,60];
%ax.XAxis.Exponent = 1;

ylabel('Au');
xlabel('$\bar{\rho}\; (\%)$','interpreter','latex');
%title('Universal Elastic Anisotropy Index');
legend('Gyroid','Diamond','Primitive','Location','northeast');
fzz = gcf;
exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\UEAI_log.pdf','ContentType','vector');


%Plot Vxy
figure(6)
%real datapoints
plot(density_gyd(:,1)*100,poisson(1,:),'-*','Color',[0, 0.4470, 0.7410]);
hold on
plot(density_dia(:,1)*100,poisson(2,:),'-*','Color',[0.8500, 0.3250, 0.0980]);
plot(density_prim(:,1)*100,poisson(3,:),'-*','Color',[0.9290, 0.6940, 0.1250]);

%ax = gca;
%ax.XMinorTick = 'on';
%ax.XAxis.TickValues = [5,10,15,20,30,40,50,60];
%ax.XAxis.Exponent = 1;
xlim([0 65]);
ylim([0.25 0.45]);
ylabel('$\nu$','interpreter','latex');
xlabel('$\bar{\rho}\; (\%)$','interpreter','latex');
legend('Gyroid','Diamond','Primitive','Location','northeast');
fzz = gcf;
exportgraphics(fzz,'F:\SYNCED FOLDER\PhD\Thesis\figures\Chapter6\results\poisson.pdf','ContentType','vector');



% %ashby bending region
% p = [0.01,1];
% C1 = 0.1;
% C2 = 4;
% n1 = 2;
% curve1 = C1*p.^n1;
% curve2 = C2*p.^n1;
% x2 = [p, fliplr(p)];
% inBetween = [curve1, fliplr(curve2)];
% fill(x2*100, inBetween,'k', 'FaceAlpha', 0.05,'EdgeAlpha', 0);
% C1 = 0.1;
% C2 = 4;
% n1 = 1;
% curve1 = C1*p.^n1;
% curve2 = C2*p.^n1;
% x2 = [p, fliplr(p)];
% inBetween = [curve1, fliplr(curve2)];
% fill(x2*100, inBetween,'k', 'FaceAlpha', 0.1, 'EdgeAlpha', 0);