function [verts, elems] = subdivide_tri( verts, elems)
%
% Vectorized Triangle Subdivision: split each triangle 
% input face into four new triangles. 
% 
% usage: [v1 f1] = subdivide( xyz, faces, iterations);
%
%  author:  Peter A. Karasev     25 Nov 2009 
%  edited:  Ben T. Murton       12 Aug 2021
numverts = size(verts,1);
numfaces = size(elems,1);

fk1 = elems(:,1);
fk2 = elems(:,2);
fk3 = elems(:,3);

% create averages of pairs of vertices (k1,k2), (k2,k3), (k3,k1)
    m1x = (verts( fk1,1) + verts( fk2,1) )/2;
    m1y = (verts( fk1,2) + verts( fk2,2) )/2;
    m1z = (verts( fk1,3) + verts( fk2,3) )/2;
    
    m2x = (verts( fk2,1) + verts( fk3,1) )/2;
    m2y = (verts( fk2,2) + verts( fk3,2) )/2;
    m2z = (verts( fk2,3) + verts( fk3,3) )/2;
    
    m3x = (verts( fk3,1) + verts( fk1,1) )/2;
    m3y = (verts( fk3,2) + verts( fk1,2) )/2;
    m3z = (verts( fk3,3) + verts( fk1,3) )/2;

    
vnew = [ [m1x m1y m1z]; [m2x m2y m2z]; [m3x m3y m3z] ];
clear m1x m1y m1z m2x m2y m2z m3x m3y m3z
[vnew_ ii jj] = unique(vnew, 'rows' );

clear vnew; 
m1 = jj(1:numfaces)+numverts;
m2 = jj(numfaces+1:2*numfaces)+numverts;
m3 = jj(2*numfaces+1:3*numfaces)+numverts;

tri1 = [fk1 m1 m3];
tri2 = [fk2 m2 m1];
tri3 = [ m1 m2 m3];
tri4 = [m2 fk3 m3];
clear m1 m2 m3 fk1 fk2 fk3
 
verts = [verts; vnew_]; % the new vertices
elems = [tri1; tri2; tri3; tri4]; % the new faces